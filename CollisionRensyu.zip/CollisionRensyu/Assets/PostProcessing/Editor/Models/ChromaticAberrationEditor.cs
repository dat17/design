using UnityEngine.PostProcessing;

namespace UnityEditor.PostProcessing
{
    [PostProcessingModelEditor(typeof(ChromaticAberrationModel))]
    public class ChromaticaAberrationModelEditor : DefaultPostFxModelEditor
    {
    }
}
