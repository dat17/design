﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	public Vector3 rotateVelocity = new Vector3 (0f, 120f, 0f);
	public GameObject prefShot;

	// Update is called once per frame
	void Update () {
		transform.Rotate (rotateVelocity*Time.deltaTime, Space.World);

		if (Input.GetMouseButtonDown (0)) {
			SoundPlayer.PlaySE (SoundPlayer.SE.SHOT);
			Instantiate (prefShot, transform.position, Quaternion.identity);
		}
	}
}
