﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShotExplosion : MonoBehaviour {

	public float Speed = 10f;
	public GameObject prefExplosion;
	public float RANDOM_DIR = 10f;
	private Rigidbody rig;

	// Use this for initialization
	void Start () {
		rig = GetComponent<Rigidbody> ();
		rig.velocity = Quaternion.Euler(Vector3.forward*Random.Range(-RANDOM_DIR, RANDOM_DIR))* Vector3.right * Speed;
	}

	void OnCollisionEnter(Collision col) {
		SoundPlayer.PlaySE (SoundPlayer.SE.EXPLOSION);
		Instantiate (prefExplosion, transform.position, Quaternion.identity);
		Destroy (gameObject);
	}

}
