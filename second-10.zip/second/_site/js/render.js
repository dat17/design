/**
 * 描画処理
 * デバッグ文字などを描画する
 *
 * @license MIT
 * @copyright 2017 YuTanaka@AmuseOne
 */
function render() {
    game.debug.text("mouse:"+game.input.x+","+game.input.y, 0,20);
}
