# phaser-template-simple
Phaserのもっとも簡易なテンプレートです。最初の練習用です。
